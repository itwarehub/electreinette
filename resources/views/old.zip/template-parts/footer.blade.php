


<div class="container-fluidd footer p-5 bg-warning">
   <div class="row">
      <div class="col-md-2 offset-md-1">
         <img class="footer-logo" src="{{ URL::to('/') }}/assets/img/footer.png" alt="" width="310px"; height: 96px;>
      </div>
      <div class="col-md-2">
         <ul class="ul footer-ul">
            <li>Save California</li>
            <li>Meet Reinette</li>
            <li>Platform: Contract for
               Californians
            </li>
            <li>Events</li>
            <li>Wake the Bear Merch</li>
         </ul>
      </div>
      <div class="col-md-2">
         <ul class="ul footer-ul">
            <li>Donate</li>
            <li>Volunteer</li>
            <li>Press Kit</li>
            <li>Contact</li>
         </ul>
      </div>
      <div class="col-md-2">
         <ul class="ul footer-ul">
            <li>#electreinette</li>
            <li>#wakethebearca</li>
         </ul>
      </div>
      <div class="col-md-2 col-12">
         <ul class="ul footer-ul footer-ul-social">
            <li><i class="fab fa-facebook text-white"></i></li>
            <li><i class="fab fa-instagram text-white"></i></li>
            <li><i class="fab fa-twitter text-white"></i></li>
            <li><i class="fab fa-pinterest text-white"></i></li>
            <li><i class="fab fa-tiktok text-white"></i></li>
            <li><i class="fab fa-youtube text-white"></i></li>
         </ul>
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-12">
          <p class="copyright footer-p">Elect Reinette Website &copy; 2021 by Reinette Senum for Governor is licensed under CC BY-NC-ND 4.0 </p>
      </div>
   </div>
</div>
<!-- footer container end -->