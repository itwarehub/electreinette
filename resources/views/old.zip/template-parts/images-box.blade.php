<section class="container-fluid img-slider d-none">
	<div class="row">
		<div class="col-sm-2">
			<a href="{{ URL::to('/') }}/assets/img/3.jpg">
				<figure><img class="img-fluid img-thumbnail" src="{{ URL::to('/') }}/assets/img/15.jpg" alt="Random Image"></figure>
			</a>
		</div>

		<div class="col-sm-2">
			<a href="{{ URL::to('/') }}/assets/img/2.jpg">
				<figure><img class="img-fluid img-thumbnail" src="{{ URL::to('/') }}/assets/img/2.jpg" alt="Random Image"></figure>
			</a>
		</div>

		<div class="col-sm-2">
			<a href="{{ URL::to('/') }}/assets/img/11.jpg">
				<figure><img class="img-fluid img-thumbnail" src="{{ URL::to('/') }}/assets/img/11.jpg" alt="Random Image"></figure>
			</a>
		</div>

		<div class="col-sm-2">
			<a href="{{ URL::to('/') }}/assets/img/10.jpg">
				<figure><img class="img-fluid img-thumbnail" src="{{ URL::to('/') }}/assets/img/10.jpg" alt="Random Image"></figure>
			</a>
		</div>

        <div class="col-sm-2">
			<a href="{{ URL::to('/') }}/assets/img/7.jpg">
				<figure><img class="img-fluid img-thumbnail" src="{{ URL::to('/') }}/assets/img/7.jpg" alt="Random Image"></figure>
			</a>
		</div>

        <div class="col-sm-2">
			<a href="{{ URL::to('/') }}/assets/img/9.jpg">
				<figure><img class="img-fluid img-thumbnail" src="{{ URL::to('/') }}/assets/img/9.jpg" alt="Random Image"></figure>
			</a>
		</div>
		
	</div>
</section>
<!--<div class="container-fluid bg-warning">-->
<!--	<div class="row p-3 text-center">-->
<!--	    <div class="col-md-1"></div>-->
<!--		<div class="col-md-2">-->
<!--			<h1 class="save_donate font-weight-bold">HELP SAVE CALIFORNIA</h1>-->
<!--		</div>-->
<!--		<div class="col-md-2">-->
<!--		<a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark p-5 font-weight-bold text-decoration-non save_donate">$5</h3></a>-->
<!--		</div>-->
<!--		<div class="col-md-2">-->
<!--		<a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark p-5  font-weight-bold text-decoration-non save_donate">$10</h3></a>-->
<!--		</div>-->
<!--		<div class="col-md-2">-->
<!--		<a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark p-5 font-weight-bold text-decoration-non save_donate">$20</h3></a>-->
<!--		</div>-->
<!--	<div class="col-md-2">-->
<!--			<a class="text-decoration-none" href="/donate"><h3 class="bg-white text-dark p-5 font-weight-bold text-decoration-non save_donate">	$30</h3></a>-->
<!--		</div>-->
<!--		<div class="col-md-1"></div>-->
<!--	</div>-->
<!--</div>-->


<!--<div class="container bg-warning">-->
<!--    <div class="row">-->
<!--        <div class="col-md-1"></div>-->
<!--        <div class="col-md-4 p-5 boxes-heading">-->
<!--            <h1 class="save_donate font-weight-bold">JOIN THE PARTY</h1>-->
<!--        </div>-->
<!--        <div class="col-md-6 p-3">-->
<!--            <div class="row text-center">-->
<!--                <div class="col-md-3 col-6">-->
<!--                    <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$5</h3></a>-->
<!--                </div>-->
<!--                <div class="col-md-3 col-6">-->
<!--                    <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$25</h3></a>-->
<!--                </div>-->
<!--                <div class="col-md-3 col-6">-->
<!--                    <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$50</h3></a>-->
<!--                </div>-->
<!--                <div class="col-md-3 boxes-extra-col"></div>-->
<!--                <div class="col-md-3 col-6">-->
<!--                    <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$100</h3></a>-->
<!--                </div>-->
<!--                <div class="col-md-3 col-6">-->
<!--                    <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$500</h3></a>-->
<!--                </div>-->
<!--                <div class="col-md-3 col-6">-->
<!--                    <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">OTHER</h3></a>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="col-md-1"></div>-->
<!--    </div>-->
<!--</div>-->




<div class="row bg-warning" id="boxes"><br><br><br>
    <div class="col-md-6 boxes-left my-auto text-center">
        <h1 class="save_donate font-weight-bold">HELP SAVE CALIFORNIA</h1>
    </div>
    <div class="col-md-6 boxes-right my-auto">
        <div class="row text-center">
            <div class="col-md-3 col-6">
                <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$5</h3></a>
            </div>
            <div class="col-md-3 col-6">
                <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$25</h3></a>
            </div>
            <div class="col-md-3 col-6">
                <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$50</h3></a>
            </div>
            <div class="col-md-3 boxes-extra-col"></div>
            <div class="col-md-3 col-6">
                <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$100</h3></a>
            </div>
            <div class="col-md-3 col-6">
                <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">$500</h3></a>
            </div>
            <div class="col-md-3 col-6">
                <a class="text-decoration-none" href="/donate">	<h3 class="bg-white text-dark font-weight-bold text-decoration-non save_donate">OTHER</h3></a>
            </div>
        </div>
    </div>
</div>