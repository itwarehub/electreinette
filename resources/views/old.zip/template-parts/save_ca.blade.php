

<!--<div class="row" id="save_ca"><br><br><br>-->
<!--    <div class="col-md-3 offset-md-2 mt-5 save_ca-left">-->
<!--        <h2 class="contract_heading mb-2">THE CAMPAIGN</h2>-->
<!--        <p class="text-1 text-justify">I am running for Governor as an independent, common-sense -->
<!--        candidate focused on core values and ethics, but in -->
<!--        order to turn California around we are going to need an -->
<!--        unprecedented effort by all of us working together.-->
<!--        </p>-->
<!--        <div class="">-->
<!--            <a href="/donate" class="btn btn-danger rounded-0" style="font-weight:800 !important;">MEET REINETTE</a>-->
<!--        </div>-->
<!--    </div>-->
<!--    <div class="col-md-6 px-0 offset-md-1 save_ca-right">-->
<!--        <img class="img img-responsive img-thumbnail" src="{{ URL::to('/') }}/assets/img/save_ca.jpg">-->
<!--    </div>-->
<!--</div>-->



<div class="row" id="save_ca"><br><br><br>
    <div class="col-md-6 offset-md-3 my-auto contract-col">
        <h2 class="contract_heading mb-2 text-center">THE CAMPAIGN</h2>
        <p class="text-1 text-justify text-center">I am running for Governor as an independent, common-sense 
        candidate focused on core values and ethics, but in 
        order to turn California around we are going to need an 
        unprecedented effort by all of us working together.
        </p>
        <p class="text-center">
            <a href="/donate" class="btn btn-danger rounded-0" style="font-weight:800 !important;">MEET REINETTE</a>
        </p>
    </div>
    
</div>


